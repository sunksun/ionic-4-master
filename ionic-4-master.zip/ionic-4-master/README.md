# ionic-4
Ionic 4 crud and login using MySQL (PHP)

Clone projek ini dan pindahkan ke dalam htdocs.
Cari folder login dan install npm. 
Set database menggunakan xampp dan import fail sql yang telah disertakan.
Folder server_api adalah API

Simple function sahaja. Moga bermanfaat
